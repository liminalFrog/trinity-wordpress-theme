<?php
/**
 * Trinity Custom Blocks
 * 
 * @package Trinity
 */

/**
 * Register custom Gutenberg blocks
 */
function trinity_register_theme_blocks() {
    
    // Hero Block
    register_block_type('trinity/hero', [
        'render_callback' => 'trinity_render_hero_block',
        'attributes' => [
            'backgroundType' => [
                'type' => 'string',
                'default' => 'color'
            ],
            'backgroundImage' => [
                'type' => 'string',
                'default' => ''
            ],
            'backgroundVideo' => [
                'type' => 'string',
                'default' => ''
            ],
            'backgroundColor' => [
                'type' => 'string',
                'default' => '#007cba'
            ],
            'borderRadius' => [
                'type' => 'number',
                'default' => 0
            ],
            'fullWidth' => [
                'type' => 'boolean',
                'default' => false
            ],
            'textPosition' => [
                'type' => 'string',
                'default' => 'center'
            ],
            'textAlignment' => [
                'type' => 'string',
                'default' => 'center'
            ],
            'textColor' => [
                'type' => 'string',
                'default' => '#ffffff'
            ],
            'textBackgroundColor' => [
                'type' => 'string',
                'default' => ''
            ],
            'parallax' => [
                'type' => 'boolean',
                'default' => false
            ],
            'staticBackground' => [
                'type' => 'boolean',
                'default' => false
            ],
            'content' => [
                'type' => 'string',
                'default' => ''
            ],
            'buttons' => [
                'type' => 'array',
                'default' => []
            ]
        ]
    ]);
    
    // Modal Block (keeping only unique blocks - alert, accordion, card, carousel are now in blocks/blocks.php)
    /*
    // Alert Block
    register_block_type('trinity/alert', [
        'render_callback' => 'trinity_render_theme_alert_block',
        'attributes' => [
            'variant' => [
                'type' => 'string',
                'default' => 'primary'
            ],
            'dismissible' => [
                'type' => 'boolean',
                'default' => false
            ],
            'content' => [
                'type' => 'string',
                'default' => ''
            ]
        ]
    ]);
    
    // Accordion Block
    register_block_type('trinity/accordion', [
        'render_callback' => 'trinity_render_accordion_block',
        'attributes' => [
            'items' => [
                'type' => 'array',
                'default' => []
            ],
            'allowMultiple' => [
                'type' => 'boolean',
                'default' => false
            ]
        ]
    ]);
    
    // Card Block
    register_block_type('trinity/card', [
        'render_callback' => 'trinity_render_card_block',
        'attributes' => [
            'title' => [
                'type' => 'string',
                'default' => ''
            ],
            'content' => [
                'type' => 'string',
                'default' => ''
            ],
            'image' => [
                'type' => 'string',
                'default' => ''
            ],
            'link' => [
                'type' => 'string',
                'default' => ''
            ],
            'linkText' => [
                'type' => 'string',
                'default' => 'Read More'
            ],
            'stretched' => [
                'type' => 'boolean',
                'default' => false
            ]
        ]
    ]);
    
    // Carousel Block
    register_block_type('trinity/carousel', [
        'render_callback' => 'trinity_render_carousel_block',
        'attributes' => [
            'slides' => [
                'type' => 'array',
                'default' => []
            ],
            'height' => [
                'type' => 'number',
                'default' => 400
            ],
            'borderRadius' => [
                'type' => 'number',
                'default' => 0
            ],
            'fullWidth' => [
                'type' => 'boolean',
                'default' => false
            ],
            'autoPlay' => [
                'type' => 'boolean',
                'default' => true
            ],
            'interval' => [
                'type' => 'number',
                'default' => 5000
            ]
        ]
    ]);
    */
    
    // Modal Block
    register_block_type('trinity/modal', [
        'render_callback' => 'trinity_render_modal_block',
        'attributes' => [
            'modalId' => [
                'type' => 'string',
                'default' => ''
            ],
            'size' => [
                'type' => 'string',
                'default' => 'md'
            ],
            'title' => [
                'type' => 'string',
                'default' => ''
            ],
            'content' => [
                'type' => 'string',
                'default' => ''
            ],
            'triggerType' => [
                'type' => 'string',
                'default' => 'button'
            ],
            'triggerText' => [
                'type' => 'string',
                'default' => 'Open Modal'
            ],
            'triggerOnLoad' => [
                'type' => 'boolean',
                'default' => false
            ]
        ]
    ]);
}
add_action('init', 'trinity_register_theme_blocks');

/**
 * Render Hero Block
 */
function trinity_render_hero_block($attributes) {
    $background_style = '';
    $container_class = $attributes['fullWidth'] ? 'container-fluid' : 'container';
    $hero_classes = ['trinity-hero', 'position-relative', 'overflow-hidden'];
    
    if ($attributes['parallax']) {
        $hero_classes[] = 'parallax';
    }
    
    if ($attributes['staticBackground']) {
        $hero_classes[] = 'static-background';
    }
    
    // Background styling
    if ($attributes['backgroundType'] === 'image' && !empty($attributes['backgroundImage'])) {
        $background_style = 'background-image: url(' . esc_url($attributes['backgroundImage']) . '); background-size: cover; background-position: center;';
    } elseif ($attributes['backgroundType'] === 'color') {
        $background_style = 'background-color: ' . esc_attr($attributes['backgroundColor']) . ';';
    }
    
    if ($attributes['borderRadius']) {
        $background_style .= 'border-radius: ' . intval($attributes['borderRadius']) . 'px;';
    }
    
    $text_style = 'color: ' . esc_attr($attributes['textColor']) . ';';
    if (!empty($attributes['textBackgroundColor'])) {
        $text_style .= 'background-color: ' . esc_attr($attributes['textBackgroundColor']) . '; padding: 1rem; border-radius: 0.5rem;';
    }
    
    $content_classes = ['hero-content', 'py-5'];
    $content_classes[] = 'text-' . esc_attr($attributes['textAlignment']);
    
    if ($attributes['textPosition'] === 'top') {
        $content_classes[] = 'align-items-start';
    } elseif ($attributes['textPosition'] === 'bottom') {
        $content_classes[] = 'align-items-end';
    } else {
        $content_classes[] = 'align-items-center';
    }
    
    ob_start();
    ?>
    <div class="<?php echo esc_attr(implode(' ', $hero_classes)); ?>" style="<?php echo esc_attr($background_style); ?>">
        <?php if ($attributes['backgroundType'] === 'video' && !empty($attributes['backgroundVideo'])) : ?>
            <video class="hero-video" autoplay muted loop>
                <source src="<?php echo esc_url($attributes['backgroundVideo']); ?>" type="video/mp4">
            </video>
        <?php endif; ?>
        
        <div class="<?php echo esc_attr($container_class); ?>">
            <div class="row min-vh-50 d-flex <?php echo esc_attr(implode(' ', $content_classes)); ?>">
                <div class="col-12">
                    <div class="hero-text" style="<?php echo esc_attr($text_style); ?>">
                        <?php echo wp_kses_post($attributes['content']); ?>
                        
                        <?php if (!empty($attributes['buttons'])) : ?>
                            <div class="hero-buttons mt-3">
                                <?php foreach ($attributes['buttons'] as $button) : ?>
                                    <a href="<?php echo esc_url($button['link']); ?>" 
                                       class="btn btn-<?php echo esc_attr($button['variant']); ?> btn-<?php echo esc_attr($button['size']); ?> me-2 mb-2"
                                       style="border-radius: <?php echo intval($button['borderRadius']); ?>px;">
                                        <?php echo esc_html($button['text']); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Conflicting blocks commented out - these blocks are now handled by blocks/blocks.php
/*
/**
 * Render Alert Block (Theme version)
 */
/*
function trinity_render_theme_alert_block($attributes) {
    $alert_classes = ['alert', 'alert-' . esc_attr($attributes['variant'])];
    
    if ($attributes['dismissible']) {
        $alert_classes[] = 'alert-dismissible';
        $alert_classes[] = 'fade';
        $alert_classes[] = 'show';
    }
    
    ob_start();
    ?>
    <div class="<?php echo esc_attr(implode(' ', $alert_classes)); ?>" role="alert">
        <?php echo wp_kses_post($attributes['content']); ?>
        <?php if ($attributes['dismissible']) : ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Render Accordion Block
 */
function trinity_render_accordion_block($attributes) {
    if (empty($attributes['items'])) {
        return '';
    }
    
    $accordion_id = 'accordion-' . wp_generate_uuid4();
    $data_parent = $attributes['allowMultiple'] ? '' : 'data-bs-parent="#' . $accordion_id . '"';
    
    ob_start();
    ?>
    <div class="accordion" id="<?php echo esc_attr($accordion_id); ?>">
        <?php foreach ($attributes['items'] as $index => $item) : 
            $item_id = $accordion_id . '-item-' . $index;
            $show_class = ($index === 0) ? 'show' : '';
            $collapsed_class = ($index === 0) ? '' : 'collapsed';
            $expanded = ($index === 0) ? 'true' : 'false';
        ?>
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-<?php echo esc_attr($item_id); ?>">
                    <button class="accordion-button <?php echo esc_attr($collapsed_class); ?>" 
                            type="button" 
                            data-bs-toggle="collapse" 
                            data-bs-target="#collapse-<?php echo esc_attr($item_id); ?>" 
                            aria-expanded="<?php echo esc_attr($expanded); ?>" 
                            aria-controls="collapse-<?php echo esc_attr($item_id); ?>">
                        <?php echo esc_html($item['title']); ?>
                    </button>
                </h2>
                <div id="collapse-<?php echo esc_attr($item_id); ?>" 
                     class="accordion-collapse collapse <?php echo esc_attr($show_class); ?>" 
                     aria-labelledby="heading-<?php echo esc_attr($item_id); ?>" 
                     <?php echo $data_parent; ?>>
                    <div class="accordion-body">
                        <?php echo wp_kses_post($item['content']); ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Render Card Block
 */
function trinity_render_card_block($attributes) {
    $card_classes = ['card', 'h-100'];
    
    ob_start();
    ?>
    <div class="<?php echo esc_attr(implode(' ', $card_classes)); ?>">
        <?php if (!empty($attributes['image'])) : ?>
            <img src="<?php echo esc_url($attributes['image']); ?>" 
                 class="card-img-top rounded-top" 
                 alt="<?php echo esc_attr($attributes['title']); ?>">
        <?php endif; ?>
        
        <div class="card-body">
            <?php if (!empty($attributes['title'])) : ?>
                <h5 class="card-title"><?php echo esc_html($attributes['title']); ?></h5>
            <?php endif; ?>
            
            <?php if (!empty($attributes['content'])) : ?>
                <p class="card-text"><?php echo wp_kses_post($attributes['content']); ?></p>
            <?php endif; ?>
            
            <?php if (!empty($attributes['link'])) : ?>
                <a href="<?php echo esc_url($attributes['link']); ?>" 
                   class="btn btn-primary <?php echo $attributes['stretched'] ? 'stretched-link' : ''; ?>">
                    <?php echo esc_html($attributes['linkText']); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Render Carousel Block
 */
function trinity_render_carousel_block($attributes) {
    if (empty($attributes['slides'])) {
        return '';
    }
    
    $carousel_id = 'carousel-' . wp_generate_uuid4();
    $container_class = $attributes['fullWidth'] ? 'container-fluid' : 'container';
    $style = 'height: ' . intval($attributes['height']) . 'px;';
    
    if ($attributes['borderRadius']) {
        $style .= 'border-radius: ' . intval($attributes['borderRadius']) . 'px; overflow: hidden;';
    }
    
    ob_start();
    ?>
    <div class="<?php echo esc_attr($container_class); ?>">
        <div id="<?php echo esc_attr($carousel_id); ?>" 
             class="carousel slide" 
             data-bs-ride="<?php echo $attributes['autoPlay'] ? 'carousel' : 'false'; ?>"
             data-bs-interval="<?php echo intval($attributes['interval']); ?>"
             style="<?php echo esc_attr($style); ?>">
            
            <div class="carousel-indicators">
                <?php foreach ($attributes['slides'] as $index => $slide) : ?>
                    <button type="button" 
                            data-bs-target="#<?php echo esc_attr($carousel_id); ?>" 
                            data-bs-slide-to="<?php echo intval($index); ?>" 
                            class="<?php echo ($index === 0) ? 'active' : ''; ?>"
                            aria-current="<?php echo ($index === 0) ? 'true' : 'false'; ?>"
                            aria-label="Slide <?php echo intval($index + 1); ?>"></button>
                <?php endforeach; ?>
            </div>
            
            <div class="carousel-inner h-100">
                <?php foreach ($attributes['slides'] as $index => $slide) : ?>
                    <div class="carousel-item h-100 <?php echo ($index === 0) ? 'active' : ''; ?>">
                        <img src="<?php echo esc_url($slide['image']); ?>" 
                             class="d-block w-100 h-100" 
                             style="object-fit: cover;" 
                             alt="<?php echo esc_attr($slide['alt']); ?>">
                        <?php if (!empty($slide['caption'])) : ?>
                            <div class="carousel-caption d-none d-md-block">
                                <?php echo wp_kses_post($slide['caption']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <button class="carousel-control-prev" type="button" data-bs-target="#<?php echo esc_attr($carousel_id); ?>" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#<?php echo esc_attr($carousel_id); ?>" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
*/

/**
 * Render Modal Block
 */
function trinity_render_modal_block($attributes) {
    $modal_id = !empty($attributes['modalId']) ? $attributes['modalId'] : 'modal-' . wp_generate_uuid4();
    $size_class = 'modal-' . esc_attr($attributes['size']);
    
    ob_start();
    ?>
    <?php if ($attributes['triggerType'] === 'button') : ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#<?php echo esc_attr($modal_id); ?>">
            <?php echo esc_html($attributes['triggerText']); ?>
        </button>
    <?php elseif ($attributes['triggerType'] === 'link') : ?>
        <a href="#" data-bs-toggle="modal" data-bs-target="#<?php echo esc_attr($modal_id); ?>">
            <?php echo esc_html($attributes['triggerText']); ?>
        </a>
    <?php endif; ?>
    
    <div class="modal fade" id="<?php echo esc_attr($modal_id); ?>" tabindex="-1" aria-labelledby="<?php echo esc_attr($modal_id); ?>Label" aria-hidden="true">
        <div class="modal-dialog <?php echo esc_attr($size_class); ?>">
            <div class="modal-content">
                <?php if (!empty($attributes['title'])) : ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="<?php echo esc_attr($modal_id); ?>Label">
                            <?php echo esc_html($attributes['title']); ?>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="modal-body">
                    <?php echo wp_kses_post($attributes['content']); ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($attributes['triggerOnLoad']) : ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var modal = new bootstrap.Modal(document.getElementById('<?php echo esc_js($modal_id); ?>'));
                modal.show();
            });
        </script>
    <?php endif; ?>
    <?php
    return ob_get_clean();
}

/**
 * Add block category
 */
function trinity_block_categories($categories) {
    return array_merge($categories, [
        [
            'slug' => 'trinity',
            'title' => esc_html__('Trinity Blocks', 'trinity'),
            'icon' => 'layout',
        ],
    ]);
}
add_filter('block_categories_all', 'trinity_block_categories');
?>
